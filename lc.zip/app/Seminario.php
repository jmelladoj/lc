<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Seminario extends Model
{
    //
    protected $guarded = ['id'];
}
