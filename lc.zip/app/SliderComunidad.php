<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderComunidad extends Model
{
    //
    protected $guarded = [];
    
    protected $table = 'slider_comunidades';
    
}
