<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Asesoria extends Model
{
    //
    protected $guarded = [];
    
    public function usuario(){
        return $this->belongsTo(User::class, 'user_id');
    }
}
