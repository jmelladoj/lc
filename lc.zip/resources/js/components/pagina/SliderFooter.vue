<template> 
    <section class="sec-padding">
        <div class="container">
            <carousel :per-page="6" :autoplay="true" :paginationActiveColor="'#3F8A24'" :loop="true">
                <slide>
                    <div class="brand-item">
                        <a href="https://www.achs.cl" target="__blank">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZR_c-lAnb50_xyW69vgaZxX3BglsamSQDm68Wm75iwXUPZIua" alt="brand" />
                        </a>
                    </div>
                </slide>

                <slide>
                    <div class="brand-item">
                        <a href="https://www.mutual.cl"  target="__blank">
                            <img src="https://www.mutual.cl/portal/wcm/connect/7d503151-1f4f-4cbc-9f7c-df7804ce173d/logoMutual.png?MOD=AJPERES&CONVERT_TO=url&CACHEID=ROOTWORKSPACE-7d503151-1f4f-4cbc-9f7c-df7804ce173d-mxSLM3T" alt="brand" />
                        </a>
                    </div>
                </slide>

                <slide>
                    <div class="brand-item">
                        <a href="https://www.ist.cl"  target="__blank">
                            <img src="http://www.ist.cl/wp-content/uploads/2019/01/logo-web.png" alt="brand" />
                        </a>
                    </div>
                </slide>

                <slide>
                    <div class="brand-item">
                        <a href="https://www.isl.gob.cl/"  target="__blank">
                            <img src="https://www.isl.gob.cl/wp-content/uploads/logo.png" alt="brand" />
                        </a>
                    </div>
                </slide>

                <slide>
                    <div class="brand-item">
                        <a href="https://www.dt.gob.cl"  target="__blank">
                            <img src="https://www.dt.gob.cl/portal/1626/channels-912_imagen_portada.thumb_i652x340.jpg" alt="brand" />
                        </a>
                    </div>
                </slide>

                <slide>
                    <div class="brand-item">
                        <a href="http://seremi13.redsalud.gob.cl/"  target="__blank">
                            <img src="http://seremi13.redsalud.gob.cl/wrdprss_minsal/wp-content/themes/minsal-wp-template/assets/img/header/logo.jpg" alt="brand" />
                        </a>
                    </div>
                </slide>

                <slide>
                    <div class="brand-item">
                        <a href="https://mma.gob.cl/"  target="__blank">
                            <img src="https://mma.gob.cl/wp-content/uploads/2018/11/logo-mma.png" alt="brand" />
                        </a>
                    </div>
                </slide>
            </carousel>
        </div>

    </section>
</template>