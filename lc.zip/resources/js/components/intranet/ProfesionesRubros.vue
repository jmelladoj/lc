<template>
    <div>
        <profesiones></profesiones>
        <rubros></rubros>
    </div>
</template>