@extends('layouts.app')

@section('content')
    <section class="breadcrumb">
        <div class="breadcrumb-content">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2 class="breadcrumb-title">Políticas y acuerdos de privacidad</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="sec-padding">
        <div class="container">
            <politicas></politicas>
        </div>
    </section>
@endsection