@section('title', 'LEBENCO - Mi perfil')

@section('seccion', 'Mi perfil')

@extends('layouts.intranet')

@section('content')
    @include('intranet.general.editarUsuario')
@endsection

